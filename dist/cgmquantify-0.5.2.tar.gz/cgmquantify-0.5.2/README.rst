cgm quantify
----------
30 metrics of glucose and glucose variability= visualizations
